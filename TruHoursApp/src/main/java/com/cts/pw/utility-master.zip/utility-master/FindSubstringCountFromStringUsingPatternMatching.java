import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FindSubstringCountFromStringUsingPatternMatching {

	public static void main(String[] args) {
		getSubStringCountFromString("I love India and the World loves India", "India");

	}

	private static int getSubStringCountFromString(String Str, String subStrToSearch) {
		Pattern pattern = Pattern.compile(subStrToSearch, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(Str);

		int count = 0;
		int i = 0;
		while (matcher.find(i)) {

			System.out.println(subStrToSearch + " found at position => " + matcher.start());
			count++;

			i = matcher.start() + 1;
		}

		System.out.println(count);
		return count;
	}

}
